﻿function Get-VBoxNatRuleFromLine {
    # intern: Forwarding(n)-Zeilen enthalten keine Adapternummer -> anhand der vorangehenden natnetN/nicN-Zeilen zuordnen
    param([string]$VMName, [string[]]$Line)
    $adapter = 0
    foreach ($l in $Line) {
        if ($l -match '^(?:natnet|nic)(?<n>\d+)=') { $adapter = [int]$Matches['n']; continue }
        if ($l -match '^Forwarding\(\d+\)="(?<r>.*)"\s*$') {
            $p = $Matches['r'].Split(',')
            if ($p.Count -ge 6) {
                [pscustomobject]@{
                    PSTypeName = 'VBoxPS.NatPortForward'
                    VMName     = $VMName
                    Adapter    = $adapter
                    RuleName   = $p[0]
                    Protocol   = $p[1].ToUpperInvariant()
                    HostIP     = $p[2]
                    HostPort   = ConvertTo-VBoxInt $p[3]
                    GuestIP    = $p[4]
                    GuestPort  = ConvertTo-VBoxInt $p[5]
                }
            }
        }
    }
}
