﻿#region Modulzustand
$script:VBoxManagePath  = $null
$script:VBoxVersion     = $null
$script:VBoxHelpCache   = @{}
$script:VBoxOSTypeCache = $null
$script:IsWin           = ($PSVersionTable.PSEdition -eq 'Desktop') -or ($IsWindows -eq $true)
# Zustände, in denen die VM keine Session hält (modifyvm & Co. möglich)
$script:VBoxOfflineStates = @('poweroff', 'saved', 'aborted', 'aborted-saved', 'teleported')
#endregion

function Resolve-VBoxManagePath {
    [CmdletBinding()]
    [OutputType([string])]
    param()

    if ($script:VBoxManagePath -and (Test-Path -LiteralPath $script:VBoxManagePath -PathType Leaf)) {
        return $script:VBoxManagePath
    }

    $exeName    = if ($script:IsWin) { 'VBoxManage.exe' } else { 'VBoxManage' }
    $candidates = New-Object System.Collections.Generic.List[string]

    if ($env:VBOXPS_VBOXMANAGE) { $candidates.Add($env:VBOXPS_VBOXMANAGE) }
    foreach ($dir in @($env:VBOX_MSI_INSTALL_PATH, $env:VBOX_INSTALL_PATH)) {
        if ($dir) { $candidates.Add((Join-Path -Path $dir -ChildPath $exeName)) }
    }
    if ($script:IsWin) {
        foreach ($pf in @($env:ProgramFiles, $env:ProgramW6432)) {
            if ($pf) { $candidates.Add((Join-Path -Path $pf -ChildPath 'Oracle\VirtualBox\VBoxManage.exe')) }
        }
    }
    else {
        $candidates.Add('/usr/bin/VBoxManage')
        $candidates.Add('/usr/local/bin/VBoxManage')
        $candidates.Add('/Applications/VirtualBox.app/Contents/MacOS/VBoxManage')
    }
    $cmd = Get-Command -Name 'VBoxManage' -CommandType Application -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($cmd) { $candidates.Add($cmd.Path) }

    foreach ($c in $candidates) {
        if ($c -and (Test-Path -LiteralPath $c -PathType Leaf)) {
            $script:VBoxManagePath = $c
            Write-Verbose "VBoxManage gefunden: $c"
            return $c
        }
    }
    throw 'VBoxManage wurde nicht gefunden. Ist VirtualBox installiert? Pfad ggf. mit Set-VBoxManagePath -Path <Pfad> festlegen.'
}

function ConvertTo-VBoxArgumentString {
    # Baut einen Kommandozeilen-String nach den Windows-/CRT-Quoting-Regeln.
    # .NET wendet dieselben Regeln auch unter Linux/macOS an -> ein Codepfad für PS 5.1 und 7.
    [OutputType([string])]
    param([AllowEmptyString()][AllowEmptyCollection()][string[]]$ArgumentList)

    $parts = foreach ($a in $ArgumentList) {
        if ($null -eq $a -or $a -eq '') { '""'; continue }
        if ($a -notmatch '[\s"]') { $a; continue }
        $escaped = [regex]::Replace($a, '(\\*)"', '$1$1\"')
        $escaped = [regex]::Replace($escaped, '(\\+)$', '$1$1')
        '"' + $escaped + '"'
    }
    $parts -join ' '
}

function Split-VBoxOutput {
    param([AllowEmptyString()][string]$Text)
    if ([string]::IsNullOrEmpty($Text)) { return }
    $Text.TrimEnd([char[]]"`r`n") -split '\r?\n'
}

function Format-VBoxErrorMessage {
    param([string[]]$ArgumentList, $Result)
    $msg = (@(Split-VBoxOutput $Result.StdErr) | Where-Object { $_ -and $_ -notmatch '^\s*\d+%' }) -join ' '
    if (-not $msg) { $msg = "$($Result.StdOut)".Trim() }
    'VBoxManage {0} fehlgeschlagen (Exit-Code {1}): {2}' -f ($ArgumentList -join ' '), $Result.ExitCode, $msg
}

function Invoke-VBoxManageCore {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory, Position = 0)]
        [AllowEmptyString()]
        [string[]]$ArgumentList,

        # Kein throw bei Exit-Code <> 0, stattdessen Ergebnisobjekt zurückgeben
        [switch]$NoThrow
    )

    $exe       = Resolve-VBoxManagePath
    $argString = ConvertTo-VBoxArgumentString -ArgumentList $ArgumentList
    Write-Verbose "VBoxManage $argString"

    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName               = $exe
    $psi.Arguments              = $argString
    $psi.UseShellExecute        = $false
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError  = $true
    $psi.CreateNoWindow         = $true

    $proc = New-Object System.Diagnostics.Process
    $proc.StartInfo = $psi
    try {
        [void]$proc.Start()
    }
    catch {
        throw "VBoxManage konnte nicht gestartet werden ($exe): $($_.Exception.Message)"
    }

    # Beide Streams asynchron lesen, sonst droht ein Deadlock bei großen Ausgaben
    $outTask = $proc.StandardOutput.ReadToEndAsync()
    $errTask = $proc.StandardError.ReadToEndAsync()
    $proc.WaitForExit()
    $stdOut = $outTask.GetAwaiter().GetResult()
    $stdErr = $errTask.GetAwaiter().GetResult()
    $exit   = $proc.ExitCode
    $proc.Dispose()

    $result = [pscustomobject]@{
        PSTypeName = 'VBoxPS.CommandResult'
        ExitCode   = $exit
        StdOut     = $stdOut
        StdErr     = $stdErr
        Lines      = @(Split-VBoxOutput $stdOut)
    }

    if ($exit -ne 0 -and -not $NoThrow) {
        throw (Format-VBoxErrorMessage -ArgumentList $ArgumentList -Result $result)
    }
    $result
}

function Invoke-VBoxManageWithRetry {
    # Wiederholt Befehle, die kurz nach dem Ausschalten noch an einer Session-Sperre scheitern.
    param(
        [Parameter(Mandatory)][string[]]$ArgumentList,
        [int]$RetryCount = 10,
        [int]$DelayMs = 1000
    )
    for ($i = 1; ; $i++) {
        $r = Invoke-VBoxManageCore -ArgumentList $ArgumentList -NoThrow
        if ($r.ExitCode -eq 0) { return $r }
        if ($i -ge $RetryCount -or "$($r.StdErr)" -notmatch 'lock') {
            throw (Format-VBoxErrorMessage -ArgumentList $ArgumentList -Result $r)
        }
        Write-Verbose "VM noch gesperrt, neuer Versuch ($i/$RetryCount) ..."
        Start-Sleep -Milliseconds $DelayMs
    }
}

function ConvertFrom-VBoxEscapedString {
    # VBoxManage maskiert in --machinereadable je nach Version \ und " – oder auch nicht.
    # Nur entmaskieren, wenn ALLE Backslashes Teil einer gültigen Escape-Sequenz sind.
    param([AllowEmptyString()][string]$Text)
    if ($Text -notmatch '\\') { return $Text }
    $rest = [regex]::Replace($Text, '\\[\\"]', '')
    if ($rest.Contains('\')) { return $Text }
    [regex]::Replace($Text, '\\([\\"])', '$1')
}

function ConvertFrom-VBoxMachineReadable {
    # Parst key=value-Ausgaben (showvminfo/snapshot list/... --machinereadable)
    param([AllowEmptyString()][AllowEmptyCollection()][string[]]$Line)
    $result = [ordered]@{}
    foreach ($l in $Line) {
        if ($l -match '^(?:"(?<key>(?:[^"\\]|\\.)*)"|(?<key>[^="]+))=(?<value>.*)$') {
            $key   = $Matches['key']
            $value = $Matches['value']
            if ($value.Length -ge 2 -and $value[0] -eq '"' -and $value[-1] -eq '"') {
                $value = ConvertFrom-VBoxEscapedString $value.Substring(1, $value.Length - 2)
            }
            $result[$key] = $value
        }
    }
    $result
}

function ConvertFrom-VBoxList {
    # Parst "Key:   Value"-Blöcke (list hostonlyifs, list hdds, list ostypes ...), getrennt durch Leerzeilen.
    param([AllowEmptyString()][AllowEmptyCollection()][string[]]$Line)
    $current = $null
    foreach ($l in @($Line) + '') {
        if ([string]::IsNullOrWhiteSpace($l)) {
            if ($current -and $current.Count) { [pscustomobject]$current }
            $current = $null
            continue
        }
        if ($l -match '^(?<key>[^\s:][^:]*?):\s*(?<value>.*)$') {
            if (-not $current) { $current = [ordered]@{} }
            $words = $Matches['key'] -split '[^A-Za-z0-9]+' | Where-Object { $_ }
            $key   = -join ($words | ForEach-Object { $_.Substring(0, 1).ToUpperInvariant() + $_.Substring(1) })
            if ($key -and -not $current.Contains($key)) { $current[$key] = $Matches['value'].Trim() }
        }
    }
}

function Get-VBoxVMList {
    param([switch]$Running)
    $what = if ($Running) { 'runningvms' } else { 'vms' }
    foreach ($l in (Invoke-VBoxManageCore -ArgumentList 'list', $what).Lines) {
        if ($l -match '^"(?<name>.*)"\s+\{(?<uuid>[0-9a-fA-F-]{36})\}\s*$') {
            [pscustomobject]@{ Name = $Matches['name']; UUID = $Matches['uuid'] }
        }
    }
}

function Get-VBoxVMInfoLines {
    param([Parameter(Mandatory)][string]$Name)
    (Invoke-VBoxManageCore -ArgumentList 'showvminfo', $Name, '--machinereadable').Lines
}

function Test-VBoxVMOnline {
    param([Parameter(Mandatory)][string]$Name)
    $state = (Get-VBoxVMInfo -Name $Name)['VMState']
    $script:VBoxOfflineStates -notcontains $state
}

function ConvertTo-VBoxInt {
    param($Value)
    $n = 0
    if ([int]::TryParse("$Value", [ref]$n)) { $n } else { $null }
}

function ConvertTo-VBoxOnOff {
    param([bool]$Value)
    if ($Value) { 'on' } else { 'off' }
}

function ConvertTo-VBoxGroupString {
    param([string[]]$Group)
    ($Group | ForEach-Object { if ($_.StartsWith('/')) { $_ } else { '/' + $_ } }) -join ','
}

function ConvertTo-VBoxVMObject {
    param([System.Collections.IDictionary]$Info, [switch]$IncludeInfo)
    $cfg = $Info['CfgFile']
    $obj = [ordered]@{
        PSTypeName   = 'VBoxPS.VM'
        Name         = $Info['name']
        UUID         = $Info['UUID']
        State        = $Info['VMState']
        OSType       = $Info['ostype']
        MemoryMB     = ConvertTo-VBoxInt $Info['memory']
        CPUs         = ConvertTo-VBoxInt $Info['cpus']
        VRAMMB       = ConvertTo-VBoxInt $Info['vram']
        Firmware     = $Info['firmware']
        Groups       = if ($Info['groups']) { @($Info['groups'] -split ',') } else { @() }
        Description  = $Info['description']
        ConfigFile   = $cfg
        Directory    = if ($cfg) { Split-VBoxParentPath $cfg } else { $null }
        StateChanged = $Info['VMStateChangeTime']
    }
    if ($IncludeInfo) { $obj['Info'] = $Info }
    [pscustomobject]$obj
}

function Resolve-VBoxHostPath {
    # Relative Pfade gegen das aktuelle PowerShell-Verzeichnis auflösen
    # (VBoxManage würde sie sonst relativ zu seinem eigenen Arbeitsverzeichnis interpretieren).
    param([Parameter(Mandatory)][string]$Path)
    try { $ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($Path) }
    catch { $Path }   # z. B. Laufwerk existiert nicht als PS-Drive -> unverändert an VBoxManage geben
}

function Get-VBoxVersionInternal {
    if (-not $script:VBoxVersion) {
        $raw = ((Invoke-VBoxManageCore -ArgumentList '--version').Lines | Where-Object { $_ } | Select-Object -Last 1).Trim()
        $ver = $null; $rev = $null
        if ($raw -match '^(?<v>\d+\.\d+\.\d+)') { $ver = [version]$Matches['v'] }
        if ($raw -match 'r(?<r>\d+)$') { $rev = [int]$Matches['r'] }
        $script:VBoxVersion = [pscustomobject]@{
            PSTypeName = 'VBoxPS.Version'
            Version    = $ver
            Revision   = $rev
            Raw        = $raw
            Path       = Resolve-VBoxManagePath
        }
    }
    $script:VBoxVersion
}

function Assert-VBoxVersion {
    param([Parameter(Mandatory)][version]$Minimum, [Parameter(Mandatory)][string]$Feature)
    $v = (Get-VBoxVersionInternal).Version
    if ($v -and $v -lt $Minimum) {
        throw "$Feature erfordert VirtualBox $Minimum oder neuer (installiert: $v)."
    }
}

function Get-VBoxHelpText {
    param([Parameter(Mandatory)][string]$Command)
    if (-not $script:VBoxHelpCache.ContainsKey($Command)) {
        $r = Invoke-VBoxManageCore -ArgumentList 'help', $Command -NoThrow
        $script:VBoxHelpCache[$Command] = "$($r.StdOut)`n$($r.StdErr)"
    }
    $script:VBoxHelpCache[$Command]
}

function New-VBoxPasswordFile {
    # Passwörter nie auf der Kommandozeile übergeben (sichtbar in Prozesslisten/Logs)
    param([Parameter(Mandatory)][securestring]$Password)
    $path  = [System.IO.Path]::GetTempFileName()
    $plain = (New-Object System.Net.NetworkCredential('', $Password)).Password
    [System.IO.File]::WriteAllText($path, $plain, (New-Object System.Text.UTF8Encoding($false)))
    $path
}

function Remove-VBoxPasswordFile {
    param([string]$Path)
    if ($Path -and (Test-Path -LiteralPath $Path)) {
        try { [System.IO.File]::WriteAllText($Path, ('x' * 64)) } catch { }
        Remove-Item -LiteralPath $Path -Force -ErrorAction SilentlyContinue
    }
}

function Get-VBoxGuestCredentialArgument {
    param([Parameter(Mandatory)][pscredential]$Credential, [Parameter(Mandatory)][string]$PasswordFile)
    $user   = $Credential.UserName
    $domain = $null
    if ($user -match '^(?<d>[^\\]+)\\(?<u>.+)$') { $domain = $Matches['d']; $user = $Matches['u'] }
    $a = @('--username', $user, '--passwordfile', $PasswordFile)
    if ($domain -and $domain -ne '.') { $a += '--domain', $domain }
    $a
}

function Get-VBoxNicArgument {
    # modifyvm-Argumente für Typ + Anbindung eines Netzwerkadapters
    param([int]$Adapter, [string]$Type, [string]$NetworkName)
    switch ($Type) {
        'None'       { "--nic$Adapter"; 'none' }
        'Null'       { "--nic$Adapter"; 'null' }
        'NAT'        { "--nic$Adapter"; 'nat' }
        'NATNetwork' { "--nic$Adapter"; 'natnetwork'; "--nat-network$Adapter"; $NetworkName }
        'Bridged'    { "--nic$Adapter"; 'bridged'; "--bridgeadapter$Adapter"; $NetworkName }
        'HostOnly'   { "--nic$Adapter"; 'hostonly'; "--hostonlyadapter$Adapter"; $NetworkName }
        'Internal'   { "--nic$Adapter"; 'intnet'; "--intnet$Adapter"; $(if ($NetworkName) { $NetworkName } else { 'intnet' }) }
    }
}

function Format-VBoxMac {
    param([string]$Mac)
    if ($Mac -match '^[0-9A-Fa-f]{12}$') { ($Mac.ToUpperInvariant() -replace '(..)(?!$)', '$1:') } else { $Mac }
}

function Split-VBoxParentPath {
    # Provider-unabhängig (VBoxManage liefert Host-Pfade, die nicht zwingend auf einem PS-Laufwerk liegen)
    param([string]$Path)
    $Path -replace '[\\/][^\\/]*$', ''
}

function Join-VBoxPath {
    param([string]$Parent, [string]$Child)
    $sep = if ($Parent -match '\\') { '\' } else { '/' }
    $Parent.TrimEnd('\', '/') + $sep + $Child
}
